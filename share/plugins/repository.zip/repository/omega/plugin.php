<?php
/**
 *  OMEGA Plugin for curriculum
 * @abstract This file is part of curriculum - http://www.joachimdieterich.de
 * @package plugins
 * @filename plugin.php
 * @copyright 2015 Joachim Dieterich
 * @author Joachim Dieterich
 * @date 2015.09.26 14:12
 * @license 
 *
 * All rights reserved    
 */
/**
 * Über diese Klasse lassen sich Medien von OMEGA (omega.bildung-rp.de) einbinden.
 */
class plugin_omega extends plugin_base { 
    
    public function setReference($dependency, $id, $reference){
        $type       = $this->resolveDependency($dependency);
        
        $db = DB::prepare('SELECT COUNT(id) FROM plugin_omega WHERE objective_id = ? AND type = ?');
        $db->execute(array($id, $type));
        if($db->fetchColumn() >= 1) { 
            if ($reference != ''){
                $db = DB::prepare('UPDATE plugin_omega SET reference = ? WHERE objective_id = ? AND type = ?');
                $db->execute(array($reference, $id, $type));   
            } else {
                $db = DB::prepare('DELETE FROM plugin_omega WHERE objective_id = ? AND type = ?');
                $db->execute(array($id, $type));   
            }
        } else {
            if ($reference != ''){
                $db = DB::prepare('INSERT INTO plugin_omega (objective_id, type, reference) VALUES (?,?,?)');
                $db->execute(array($id, $type, $reference));
            }
        }
    }
    
    public function getReference($dependency, $id){
           $db         = DB::prepare('SELECT reference FROM plugin_omega WHERE objective_id = ? AND type = ?');   
           $db->execute(array($id, $this->resolveDependency($dependency)));
           $result     = $db->fetchObject();
           if ($result) {
               return $result->reference;
           } else {
               return false;           
           }
    }

    public function getFiles ($dependency, $id, $files){
        $type       = $this->resolveDependency($dependency);
        $db         = DB::prepare('SELECT reference FROM plugin_omega WHERE objective_id = ? AND type = ?');   
        $db->execute(array($id, $type));
        $result     = $db->fetchObject();
        if (isset($result->reference)) { 
            $doc        = new DOMDocument();
            $doc->load($this->config('api').$this->config('query').$result->reference);
            $items      = $doc->getElementsByTagName('item');
            $tmp_file   = new File();
            foreach ($items as $item) {
                $elements = $item->getElementsByTagName('element');
                foreach ($elements as $element) {
                       switch ($element->getElementsByTagName('field')->item(0)->nodeValue) {
                            case 'general_identifier': 
                            case 'educational_resourcetype':
                            case 'technical_format':
                                break;
                            case 'rights_description_text':     $tmp_file->license      = $element->getElementsByTagName('value')->item(0)->nodeValue;

                                break;
                            case 'general_title_de':            $tmp_file->title        = $element->getElementsByTagName('value')->item(0)->nodeValue;
                                                                $tmp_file->type         ='external';
                                                                $tmp_file->file_context = 5;
                                break;
                            case 'general_description_de':      $tmp_file->description  = $element->getElementsByTagName('value')->item(0)->nodeValue;
                                break;
                            case 'technical_thumbnail':         $tmp_file->file_version['t']['filename'] = $element->getElementsByTagName('value')->item(0)->nodeValue;
                                break;
                            case 'technical_location':          $tmp_file->filename     = $element->getElementsByTagName('value')->item(0)->nodeValue;
                                                                $tmp_file->path         = $element->getElementsByTagName('value')->item(0)->nodeValue;
                                break;
                            default:
                                break;
                        }
                }
                if (isset($tmp_file->title)){ // Hack: to prevent empty offset 0
                    $tmp_array[] = clone $tmp_file;
                }
            }
            
            if (is_array($files) AND isset($tmp_file->title)){ // beide Vorhanden
                return array_merge($files, $tmp_array) ;
            } else if (isset($tmp_file->title)) { // nur Omega vorhanden
                return $tmp_array;
            }  else {
                return false;
            }
        } else {
            return $files;
        }
    }
    
    public function count($type, $id){
        $db         = DB::prepare('SELECT COUNT(*) AS MAX FROM plugin_omega AS po WHERE objective_id = ? AND type = ?');
        $db->execute(array($id, $type));
        $res        = $db->fetchObject();
        if ($res->MAX >= 1){
            return '/ext';
        } else {
            return '';
        }
    }
    
    private function resolveDependency($dependency) {
        switch ($dependency) {
            case 'terminal_objective': return 0;
            case 'enabling_objective': return 1;
            default: break;
        }   
    }
    
    private function config($name){
        $db = DB::prepare('SELECT value FROM config_plugins WHERE plugin = ? AND name = ?');
        $db->execute(array('repository/omega', $name));
        $result = $db->fetchObject();
        if ($result){
            return $result->value;
        }   
    }
    
    

}